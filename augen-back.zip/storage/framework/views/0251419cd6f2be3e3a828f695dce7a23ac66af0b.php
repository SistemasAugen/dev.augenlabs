<!-- //Scripts de neon -->
<script src="/public/extras/js/tinymce/tinymce.min.js"></script>
<script src="/public/extras/js/gsap/TweenMax.min.js"></script>
<script src="/public/extras/js/resizeable.js"></script>
<script src="/public/extras/js/neon-api.js"></script>
<script src="/public/extras/js/neon-login.js"></script>
<script src="/public/extras/js/jquery.validate.min.js"></script>
<script src="/public/extras/js/neon-custom.js"></script>
<script src="/public/extras/js/fileinput.js"></script>
<script src="/public/extras/js/jquery.bootstrap.wizard.min.js"></script>
<script src="https://unpkg.com/jspdf@latest/dist/jspdf.min.js"></script>





<link href="https://unpkg.com/bootstrap-table@1.14.2/dist/bootstrap-table.min.css" rel="stylesheet">

<script src="https://unpkg.com/tableexport.jquery.plugin/tableExport.min.js"></script>
<script src="https://unpkg.com/tableexport.jquery.plugin/libs/jsPDF/jspdf.min.js"></script>
<script src="https://unpkg.com/tableexport.jquery.plugin/libs/jsPDF-AutoTable/jspdf.plugin.autotable.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.14.2/dist/bootstrap-table.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.14.2/dist/extensions/export/bootstrap-table-export.min.js"></script>
