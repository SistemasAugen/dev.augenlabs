<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrdersMove extends Model
{
    protected $guarded=[];
}
