<script>
    window._proyectUrl = "<?=env('APP_URL', '/') ?>";
</script>