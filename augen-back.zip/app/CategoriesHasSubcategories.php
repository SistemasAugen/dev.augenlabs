<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoriesHasSubcategories extends Model
{
    protected $guarded=[];

}
