<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<style>
		.imagen_logo{

		}



		.img-container{
			width: 100%;
			text-align: center;
		}

		.title{
			color: black;
			font-size: 12px;
			font-family: Arial,Helvetica Neue,Helvetica,sans-serif;
			font-weight: bold;
		}
		.cuerpo{
			font-size: 12px;
			text-align: justify;
		}

		.pie{
			font-size: 12px;
			font-family: Arial,Helvetica Neue,Helvetica,sans-serif; 
			text-align: left;
		}

		body{
			
			font-family: Arial,Helvetica Neue,Helvetica,sans-serif; 
			font-size: 12px;
			background-color: white;
		}


        .img-producto{
            max-width: 100px;
            max-height: 100px;
            width: 100%;
            height: 100%;
        }

		.derecha{
			text-align: right;
		}

		.text-center {
			text-align: center;
		}

		.hr_1{
			border-top: 1px solid #8c8b8b;
		}
		.hr_2 {
			border-top: 1px dashed #8c8b8b;
		}

		.hr_2 {
			background-color: #fff;
			border-top: 2px dotted #8c8b8b;
		}
		h1{
		  text-align:center;
		}
		table {
			  font-family: arial, sans-serif;
			  border-collapse: collapse;
			  width: 100%;
			}

			td, th {
			  border: 1px solid #dddddd;
			  text-align: left;
			  padding: 8px;
			}
		/*@page {
                margin: 0cm 0cm;
            }*/
			.header,

			.header {
				top: 0px;
			}
			
				
	</style>
</head>
<body>
	<div class="img-container" style="text-align: center;">		
		<img src="https://sistema.augenlabs.com/public/images/logo.png" alt="" class="imagen_logo" width="250px" >
	</div>
	<br>
	<table style="text-align:center;width: 100%;color: gray;">

		<tr>
		    <th style="text-align:center;">Estado de cuenta</th>
            <td style="text-align:center;">{{ $inputs['account_status'] }} </td>
        </tr>
        <tr>
		    <th style="text-align:center;">Semana</th>
            <td style="text-align:center;">{{ $inputs['wekeend'] }} </td>
        </tr>
        <tr>
		    <th style="text-align:center;">Cliente</th>
            <td style="text-align:center;">{{ $inputs['client'] }} </td>
        </tr>

        <tr>
		    <th style="text-align:center;">Observaciones</th>
            <td style="text-align:center;">{{ $inputs['observations'] }} </td>
        </tr>
        <tr>
		    <th style="text-align:center;" colspan="2">RX'S</th>
            
        </tr>
        <tr>
            <table>
                <tr>
                    <th style="text-align:center;">Fecha</th>
                    <th style="text-align:center;">RX´S</th>
                    <th style="text-align:center;">Descripción</th>
                    <th style="text-align:center;">Importe</th>
                </tr>
                @foreach ($inputs['rxs'] as $rx)
                    <tr>
                        <td style="text-align:center;">{{ $rx['date']}}</td>
                        <td style="text-align:center;">{{ $rx['rx']}}</td>
                        <td style="text-align:center;">{{ $rx['description']}}</td>
                        <td style="text-align:center;">{{ $rx['amount']}}</td>
                    </tr>
                @endforeach
            </table>
		    

        </tr>
        
	</table> 

    
		
</body>

</html>
