<!-- Glyphicons -->
<link rel="stylesheet" type="text/css" href="/public/extras/css/ga.css">

<!-- css webpack -->
<link rel="stylesheet" type="text/css" href="/public/css/admin.css">

<!-- /* Solo para el dashboard */ -->
<link rel="stylesheet" type="text/css" href="/public/extras/css/neon-core.css">
<link rel="stylesheet" type="text/css" href="/public/extras/css/neon-theme.css">
<link rel="stylesheet" type="text/css" href="/public/extras/css/neon-forms.css">
<link rel="stylesheet" type="text/css" href="/public/extras/css/font-awesome/css/fontawesome-all.min.css">
<link rel="stylesheet" type="text/css" href="/public/extras/css/font-awesome/css/fontawesome.min.css">
<link rel="stylesheet" type="text/css" href="/public/extras/css/font-icons/entypo/css/entypo.css">
<link rel="stylesheet" type="text/css" href="/public/extras/css/bootstrap-table.min.css">
