<table>
    <tr>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">#</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">NOMBRE DEL CLIENTE</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">NOMBRE OMERCIAL</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">DIRECCIÓN COMPLETA</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">ESTADO</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">CIUDAD</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">PDV ASIGNADO</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">NOMBRE DE CONTACTO</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">TELEFONO</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">CELULAR</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">CORREO</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">DIVISIÓN</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">FECHA DE INGRESO</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">ORIGEN DEL CLIENTE</th>
        <th style="background-color: #0096a4;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">MONOFOCAL</th>
        <th style="background-color: #0096a4;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">BIFOCAL</th>
        <th style="background-color: #0096a4;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">PROGRESIVOS</th>
        <th style="background-color: #0096a4;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">PAQUETES</th>
        <th style="background-color: #0096a4;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">TERMINADOS</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">CORREO DE NOTIFICACIONES</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">NOMBRE DE CONTACTO</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">TELEFONO DE CONTACTO</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">CORREO DE CONTACTO</th>
        <th style="background-color: #000000;color: #ffffff;font-weight: bold;text-align: center;text-transform: uppercase;">PLAZO</th>
    </tr>
    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($client->id); ?></td>
            <td><?php echo e($client->name); ?></td>
            <td><?php echo e($client->comertial_name); ?></td>
            <td><?php echo e(mb_strtoupper(trim(sprintf('%s, %s, %s, %s, %s', $client->address, $client->suburb, $client->postal_code, $client->town->name, $client->state->name)))); ?></td>
            <td><?php echo e($client->state->name); ?></td>
            <td><?php echo e($client->town->name); ?></td>
            <td><?php echo e(@$client->branch->name ?: '-'); ?></td>
            <td><?php echo e(@$client->name ?: '-'); ?></td>
            <td><?php echo e(@$client->phone ?: '-'); ?></td>
            <td><?php echo e(@$client->celphone ?: '-'); ?></td>
            <td><?php echo e(@$client->email ?: '-'); ?></td>
            <td><?php echo e(@$client->category ?: '-'); ?></td>
            <td><?php echo e(date('d/m/Y', strtotime($client->created_at))); ?></td>
            <td><?php echo e(@$client->contact_celphone ?: '-'); ?></td>
            <td><?php echo e(@$client->monofocalDiscount ?: '0'); ?> %</td>
            <td><?php echo e(@$client->bifocalDiscount ?: '0'); ?> %</td>
            <td><?php echo e(@$client->progresiveDiscount ?: '0'); ?> %</td>
            <td><?php echo e(@$client->packagesDiscount ?: '0'); ?> %</td>
            <td><?php echo e(@$client->finishedDiscount ?: '0'); ?> %</td>
            <td><?php echo e(@$client->notification_mail ?: '-'); ?></td>
            <td><?php echo e(@$client->contact_name ?: '-'); ?></td>
            <td><?php echo e(@$client->contact_phone ?: '-'); ?></td>
            <td><?php echo e(@$client->contact_email ?: '-'); ?></td>
            <td><?php echo e(@$client->payment_plan ?: 0); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
