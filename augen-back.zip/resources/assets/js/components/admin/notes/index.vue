<template>
	<div>
		<div class="row">
			<div class="col-md-12">
				<div id="toolbar">
			        <router-link to="/notes/edit">
			        	<button class="btn btn-success btn-sm">
				            <i class="fa fa-plus"></i> Nuevo
				        </button>
			        </router-link>
                    <button class="btn btn-danger btn-sm" @click="deleteRows()">
			            <i class="fa fa-trash"></i> Borrar
			        </button>
					<button class="btn btn-info btn-sm" @click="printRows()">
			            <i class="fas fa-print"></i> Imprimir
			        </button>
			        <button class="btn btn-default btn-sm" @click="sendRows(1)">
			            <i class="fas fa-envelope"></i> Enviar por correo
			        </button>
			    </div>
				<table id="rowstable"></table>
			</div>
		</div>
        <sweet-modal ref="modalrxs">
            <table id="tablerx"></table>
        </sweet-modal>
		<sweet-modal ref="modalEmails">
			<form role="form" class="form-horizontal" >

				<text-form name="name" text="Correos a enviar (separados por coma)" :data.sync="formemails" ></text-form>

				<div class="form-group">
					<div class="col-sm-12">
						
						<button type="button" class="btn btn-success pull-right" @click="sendRows(2)"><i class="far fa-save"></i> Guardar</button>
						<button type="button" class="btn btn-default pull-right" @click="$refs.modalEmails.closest()">Cancelar</button>
					</div>
				</div>
			</form>

			
        </sweet-modal>
	</div>
</template>
<script type="text/javascript">
	export default {
		data(){
			return {
				rows:{},
				formemails:null,
			}
		},
		methods:{
			mounthTable(){
				jQuery('#rowstable').bootstrapTable({
					columns: [
                        {
							field:"check",
							checkbox:true,
							align: 'center',
						},
						{
					        field: 'id',
					        title: 'ID',
					        sortable:false,
							switchable:false,
							
					    },
						{
					        field: 'client',
					        title: 'Cliente',
					        sortable:true,
							switchable:true,
							
					    },
                        {
					        field: 'rxsbtn',
					        title: 'Rx',
					        sortable:false,
							switchable:false,
							
					    },
                        {
					        field: 'observations',
					        title: 'Observaciones',
					        sortable:false,
							switchable:false,
							
					    },
                        {
					        field: 'total',
					        title: 'Total',
					        sortable:false,
							switchable:false,
							
					    },
                        {
					        field: 'editbtn',
					        title: 'Editar',
					        sortable:false,
							switchable:false,
							
					    },
						
						
					],
					//Boton de refrescar
					showRefresh:true,
		                        		
				});

				jQuery('#rowstable').on('refresh.bs.table',()=>{
					this.getRows();
				});

				jQuery('#rowstable').on('click-row.bs.table',(e,row,data,$element)=>{
                    if ($element == 'rxsbtn') {
                        
                        jQuery('#tablerx').bootstrapTable('removeAll');
			    	    jQuery('#tablerx').bootstrapTable('append',row.rxs);
                        this.$refs.modalrxs.open();
                    }
					else if($element == 'printbtn'){
						this.printNote(row.id);
					}
					else{
                        this.$router.push('/notes/edit/'+row.id);
                    }
				});

				this.getRows();

			},
			getRows(){
				this.$parent.inPetition=true;
				axios.get(tools.url("/api/notes")).then((response)=>{
			    	this.rows=response.data;
			    	
			    	jQuery('#rowstable').bootstrapTable('removeAll');
			    	jQuery('#rowstable').bootstrapTable('append',this.rows);
			    	this.$parent.inPetition=false;
			    }).catch((error)=>{
			        this.$parent.handleErrors(error);
			        this.$parent.inPetition=false;
			    });
			},
            deleteRows:function(){
				var rows=jQuery('#rowstable').bootstrapTable('getAllSelections');
				if(rows.length==0){
					return false;
				}
				alertify.confirm("Alerta!","¿Seguro que deseas borrar "+rows.length+" registros?",()=>{
					this.$parent.inPetition=true;
					var params={};
					params.ids=jQuery.map(rows,(row)=>{
						return row.id;
					});
					
					axios.delete(tools.url('/api/notes'),{data:params})
					.then((response)=>{
						this.$parent.showMessage(response.data.msg,"success");
						this.getRows();
						this.$parent.inPetition=false;
					})
					.catch((error)=>{
						this.$parent.handleErrors(error);
				        this.$parent.inPetition=false;
					});

				},
				()=>{
					
				});

				
			},
            mounthTableRx(){
				jQuery('#tablerx').bootstrapTable({
					columns: [
						
						{
					        field: 'date',
					        title: 'Fecha',
					        sortable:true,
							switchable:true,
							
					    },
                        {
					        field: 'rx',
					        title: 'Rx',
					        sortable:false,
							switchable:false,
							
					    },
                        {
					        field: 'description',
					        title: 'Descripcion',
					        sortable:false,
							switchable:false,
							
					    },
                        {
					        field: 'amount',
					        title: 'Importe',
					        sortable:false,
							switchable:false,
							
					    }
					],
					//Boton de refrescar
					showRefresh:true,
		                        		
				});
			},
			printRows(){
				var rows=jQuery('#rowstable').bootstrapTable('getAllSelections');
				if(rows.length==0){
					return false;
				}
				this.$parent.inPetition=true;
					var params={};
					params.ids=jQuery.map(rows,(row)=>{
						return row.id;
					});
					
					axios.post(tools.url('/api/notesprint'),params)
					.then((response)=>{
						this.getRows();
						this.$parent.inPetition=false;
						for (let z = 0; z < response.data.length; z++) {
							window.open(response.data[z]);
							
						}
					})
					.catch((error)=>{
						this.$parent.handleErrors(error);
				        this.$parent.inPetition=false;
					});
			},
			sendRows(type){
				if (type == 1) {
					var rows=jQuery('#rowstable').bootstrapTable('getAllSelections');
					if(rows.length==0){
						return false;
					}
					this.$refs.modalEmails.open();
				}
				else{
					this.$parent.inPetition=true;
					var rows=jQuery('#rowstable').bootstrapTable('getAllSelections');
					var params={};
					params.ids=jQuery.map(rows,(row)=>{
						return row.id;
					});
					params.emails = this.formemails;
					
					axios.post(tools.url('/api/notessend'),params)
					.then((response)=>{
						this.getRows();
						this.$parent.inPetition=false;
						
						this.$parent.showMessage(response.data.msg,"success");
					})
					.catch((error)=>{
						this.$parent.handleErrors(error);
						this.$parent.inPetition=false;
					});
				}
			}
			
		},
        mounted() {
            this.mounthTable();
            this.mounthTableRx();
        }
    }
</script>