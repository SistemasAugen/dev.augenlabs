<template>
	<footer class="main">				
		&copy; 2018 <strong><a href="http://sustam.com" target="_blank">Sustam</a></strong> Version 0.1	Using <i class="fab fa-vuejs"></i> and <i class="fab fa-laravel"></i>
	</footer>
</template>

<script type="text/javascript">
	export default {
        mounted() {
            console.log('Footer mounted.');
        }
    }
</script>