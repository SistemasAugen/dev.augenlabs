<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
</head>
<body>
	<h2>Curso laravel</h2>
	<p>Hola, tu id de ticket es {!! $slug !!}</p>
</body>
</html>