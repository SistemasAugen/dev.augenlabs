<template>
	<div>
		<div class="container">
	    	<div class="row">
	        	<div class="service">
	        		<div class="col-md-6 col-md-offset-3">
	            		<div class="text-center">
	              			<h2>Frontend</h2>
	              			<p>Uso de librerias y servicios de Vuejs.<br></p>
	            		</div>
	            	<hr>
	          		</div>
	        	</div>
	      	</div>
	    </div>
	    <div class="container">
	    	<div class="row">
	    		<div class="col-md-12">
	    			<h3>Guia de inicio Frontend</h3>
	    			<iframe src="docs/Frontend.pdf" width="100%" height="500px"></iframe>
	    		</div>
	    		<div class="col-md-12">
	    			<h3>Frontend en dashboard</h3>
	    			<iframe src="docs/Frontend_admin.pdf" width="100%" height="500px"></iframe>
	    		</div>
	    	</div>
	    </div>
	</div>
</template>
<script type="text/javascript">
	export default {

	}
</script>