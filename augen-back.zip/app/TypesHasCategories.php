<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TypesHasCategories extends Model
{
    protected $guarded=[];
}
