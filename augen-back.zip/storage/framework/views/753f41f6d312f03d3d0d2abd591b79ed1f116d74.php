<!DOCTYPE html>
<html>
<head>
	<title>Cargando..</title>
	<?php echo $__env->make('shared.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<?php echo $__env->make('shared.jsDir', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="page-body" style="background-color:white;background:white;">
	<div id="app" style="height: 100%;">
		<div v-if="logged" style="height: 100%;" class="page-fade">
			<div class="page-container">
				<admin-menu ref="menu"></admin-menu>
				<div class="main-content">
					<admin-header ref="header"></admin-header>
					<hr>
					<messages ref="messages" :vclass="alert.class" :msg="alert.msg"></messages>
					<router-view ref="view"></router-view>
					<loading-spinner :loading="inPetition" color="white"></loading-spinner>

					<admin-footer ref="footer"></admin-footer>
				</div>
			</div>
		</div>
		<div v-else>
			<login></login>
		</div>
	</div>
	<script type="text/javascript" src="/public<?php echo e(mix('/js/admin.js')); ?>"></script>
	<?php echo $__env->make('shared.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
