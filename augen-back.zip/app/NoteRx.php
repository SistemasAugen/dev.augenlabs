<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NoteRx extends Model
{
    //
}
