<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Conekta_order extends Model
{
    protected $timestamps = false;
    protected $guarded=[];
}
